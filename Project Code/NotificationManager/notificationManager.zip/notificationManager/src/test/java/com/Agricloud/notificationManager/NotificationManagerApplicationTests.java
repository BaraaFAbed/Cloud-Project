package com.Agricloud.notificationManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
